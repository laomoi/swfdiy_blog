This directory contains specification snippets for ES4 features
implemented by ESC.  These are meant to serve as fit-for-humans
specifications of the features until the ES4 spec has been completed.

We hope there will be very few conflicts with the ES4 reference
implementation...
