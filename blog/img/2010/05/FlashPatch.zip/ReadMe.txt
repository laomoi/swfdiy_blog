
If you don't install the software to the default directory then you can edit the NT.cfg file found in the FlashPlayerTrust folder with notepad, this will ensure that it allows the right program.

1. Put mms.cfg and FlashPlayerTrust folder into the following directory.

	C:\Windows\system32\macromed\flash\

2. Reboot and it should allow all local content from that Hard drive to work.

