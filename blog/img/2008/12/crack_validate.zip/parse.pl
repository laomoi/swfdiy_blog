use strict;

use GD::Image;


#study
my $rh_template = {};
for my $s (qw/1491 4589 6023 5834 4377 /) {
    if (-e $s . '.png') {
        my $image = GD::Image->new($s . '.png');
        qu_zao($image);
        my ($ra_x, $ra_y) = get_char_rect($image);
        my $ra_info = get_rect_info($image, $ra_x, $ra_y);
        my @n = split '', $s;
        for my $i (0..3) {
            $rh_template->{$n[$i]} = $ra_info->[$i];
        }
    }
}


use LWP::UserAgent;
my $ua = LWP::UserAgent->new;
$ua->cookie_jar({});
for my $i(1..10) {
    my $image = $ua->get('http://www,xxxxxxxxxxx.com')->content;
    open(F, '>',  "tmp.png");
    binmode F;
    print F $image;
    close F;
    print scan('tmp.png'), "\n";
}

sub scan {
    my $file = shift;
    my $image_to_scan = GD::Image->new($file);
    qu_zao($image_to_scan);
    my ($ra_x, $ra_y) = get_char_rect($image_to_scan);
    my $ra_info = get_rect_info($image_to_scan, $ra_x, $ra_y);
    
    my $result = '';
    INFO_LOOP:
    for my $info (@$ra_info) {
        my $hit = 0;
        #print $info, "\n";
        for my $n (keys %$rh_template) {
            #      print "=> $n\n";
            if (compare_info($info, $rh_template->{$n})) {
                $result .= $n;
                $hit = 1;
                last;
            }
        }
        unless ($hit) {
            $result .= 'X';
        }    
    }
    return $result;
}





sub qu_zao {
    my $image = shift;
    my $width =  $image->width;
    my $height = $image->height;
    for my $y (1..$height) {
        for my $x(1..$width) {
            if (is_zaodian($image, $x, $y)) {
                $image->setPixel($x,$y, 0);      
            }
            
        }
    }
}

sub is_zaodian {
    my $image = shift;
    my $x = shift;
    my $y = shift;
    my $index = $image->getPixel($x,$y);   
    for my $i ($x-1..$x+1) {
        for my $j ($y-1..$y+1) {
            next if $i <=0 or $j <=0;
            next if $i == $x and $j == $y;
            my $index_near = $image->getPixel($i,$j); 
            if ($index_near == $index) {
                return 0;
            }
        }
    }
    return 1;
}

sub get_char_rect {
    my $image = shift;
    my $height = $image->height;
    my $ra_rect_list = [];
    my $ra_x_range = [[1,8],[13,20], [25,32], [37,44]];
    my $ra_y_range = [[],[],[],[]];

    for my $i (0..3) {
        for my $y (1..$height) {
            for my $x ($ra_x_range->[$i]->[0]..$ra_x_range->[$i]->[1]) {
                my $index = $image->getPixel($x,$y);
                if ($index != 0) {
                    if (not defined $ra_y_range->[$i]->[0]) {
                         $ra_y_range->[$i]->[0] = $y;
                    }
                    $ra_y_range->[$i]->[1] = $y;
                    last;
                }
            }
        }
    }
    
    return ($ra_x_range, $ra_y_range);
}

sub get_rect_info {
    my $image = shift;
    my $ra_x  = shift;
    my $ra_y = shift;
    my $ra_info = [];
    for my $i (0..3) {
        my $info = '';
        for my $y ($ra_y->[$i]->[0]..$ra_y->[$i]->[1]) {
            for my $x ($ra_x->[$i]->[0]..$ra_x->[$i]->[1]) {
                 my $index = $image->getPixel($x,$y);
                $info .= $index ? 1:0;
            }
        
        }
        push @$ra_info, $info;
    }
    return $ra_info;
}

sub compare_info {
    my $info1 = shift;
    my $info2 = shift;

    my $diff = 0;
    my @is1 = split '', $info1;
    my @is2 = split '', $info2;
    
    for my $i (0..$#is1) {
        if ($is1[$i] != $is2[$i]) {
            $diff++;
        }
    }
    #print "diff:$diff\n";   
    return $diff < 10 ? 1: 0;
}
